import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { User } from './users/entities/user.entity'; // Importe a entidade

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres', // ou o seu banco de dados
      host: 'localhost',
      port: 5432,
      username: 'seu_usuario',
      password: 'sua_senha',
      database: 'seu_banco_de_dados',
      entities: [User], // Adicione a entidade aqui
      synchronize: true, // Apenas para desenvolvimento! Em produção, use migrations.
    }),
    AuthModule,
    UsersModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}