import React from 'react';
import CadastroScreen from './components/CadastroScreen';

export default function App() {
  return <CadastroScreen />;
}